### Hexlet tests and linter status:
[![Actions Status](https://github.com/AnastasiyaBobko/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/AnastasiyaBobko/python-project-49/actions)


[![Maintainability](https://api.codeclimate.com/v1/badges/87ff9a8fa7337650aafe/maintainability)](https://codeclimate.com/github/AnastasiyaBobko/python-project-49/maintainability)

https://asciinema.org/a/582521


