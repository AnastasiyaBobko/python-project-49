### Hexlet tests and linter status:
[![Actions Status](https://github.com/AnastasiyaBobko/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/AnastasiyaBobko/python-project-49/actions)


[![Maintainability](https://api.codeclimate.com/v1/badges/87ff9a8fa7337650aafe/maintainability)](https://codeclimate.com/github/AnastasiyaBobko/python-project-49/maintainability)

brain-even game
[![asciicast](https://asciinema.org/a/582521.png)](https://asciinema.org/a/582521)

brain-calc game
[![asciicast](https://asciinema.org/a/582790.png)](https://asciinema.org/a/582790)

brain-gcd game
[![asciicast](https://asciinema.org/a/583103.png)](https://asciinema.org/a/583103)

brain-progression game
[![asciicast](https://asciinema.org/a/583190.png)]  (https://asciinema.org/a/583190)

brain-prime game 
[![asciicast](https://asciinema.org/a/583200.png)] (https://asciinema.org/a/583200)